# 🎓 StudyTube

**A YouTube-style, study-only video and post platform where every upload is reviewed by AI before it goes live.**

Students upload lessons and study posts. An AI reviewer checks each one, picks the subject, scores it, and either approves it or rejects it with a reason and a tip. Only approved content reaches the feed.

## Features

- **Direct video upload**: pick a video file (up to 20 MB), no links needed.
- **Study posts**: a second section for explanations, worked examples and study tips.
- **AI approval**: fast review in the background. Approve at 70+ score. Rejections explain why and how to fix it. Obvious spam (pranks, memes, giveaways) is rejected instantly.
- **Auto subject detection**: Math, Physics, Chemistry, Biology, History, Computer Science, Languages, Study Skills.
- **YouTube-style UI**: sidebar, search, video grid, watch page, light and dark mode, mobile friendly.
- **Login system**: username and password accounts, salted PBKDF2 hashing, lockout after repeated failures.
- **Admin dashboard** (admin only): total and new users, logins, page opens, uploads per user, approval stats, storage used, 7-day upload chart, recent activity, and a review queue with Approve, Reject and Delete.

## Important: where it runs

StudyTube is a single file (`index.html`) built for the **Claude artifact runtime** on claude.ai. It uses the runtime's `db`, `assets`, `sample` (AI) and `user` capabilities for storage, uploads, AI review and identity.

That means:

- Opening `index.html` directly, or hosting it on GitHub Pages, shows the "Login required" screen, because those capabilities do not exist outside claude.ai.
- GitHub is for storing and sharing the **source code**. To run it, publish it as an artifact (below).

### Run it

1. Open a chat on [claude.ai](https://claude.ai).
2. Paste the contents of `index.html` and ask Claude to publish it as an artifact with these capabilities:

```json
{
  "assets": { "upload": "interact" },
  "db": {
    "rules": [
      { "path": "config", "read": "view", "write": "owner" },
      { "path": "logs", "read": "owner", "write": "owner" },
      { "path": "logs/{self}", "read": "interact", "write": "interact" }
    ]
  },
  "sample": {},
  "user": {}
}
```

3. Share the artifact with friends as **Contributor** so they can sign up and upload.
4. Open the page as the owner, tap **Login**, and use **Create admin** to set your admin username and password.

## How it works

| Part | What it does |
|------|--------------|
| `items` collection | Videos and posts: title, text, status, score, reason, tip, uploader, time |
| `accounts` collection | User accounts (username, salt, password hash) |
| `config/admin` | The admin account, writable only by the artifact owner |
| `logs/<id>` | Per-person visit and login activity, readable only by the owner |
| Assets | Uploaded video files |

## Limits and security notes

- The AI reviews the **title and description only**. It cannot watch the video.
- Login runs in the browser. Passwords are hashed (PBKDF2-SHA256), but hashes are readable by people who can open the page, so use strong passwords.
- Approve, reject and delete controls are hidden from non-admins, but a technical user with Contributor access could still change data. Treat it as a friendly community tool, not a high-security system.
- Activity is recorded only for people who open the page signed in to claude.ai.
- Videos are limited to 20 MB.

## Project structure

```
index.html   the whole app (HTML, CSS and JavaScript)
README.md    this file
LICENSE      MIT
```

## License

MIT. See `LICENSE`.
